"""
Utility functions and modules.
""" 